# BornStar Technology — Website

A static, production-ready marketing site for BornStar Technology. No build step, no server, no database — plain HTML/CSS/JS, so it deploys directly on GitHub Pages for free.

## Pages
- `index.html` — Home
- `solutions.html` — AI, WordPress, WhatsApp AI, Automation, Lead Gen, Care Plans, Branding
- `industries.html` — Industries served
- `portfolio.html` — Project showcase
- `about.html` — Company story, mission, vision, values
- `blog.html` — Blog listing
- `contact.html` — Contact form, business info, WhatsApp, map placeholder
- `404.html` — Not found page

## Deploy to GitHub Pages (no domain needed, ~5 minutes)

**Option A — Upload via GitHub's website (no git required):**
1. Go to [github.com/new](https://github.com/new) and create a repository named `bornstar-website` (Public).
2. Click **Add file → Upload files**, then drag in every file and folder from this project (keep the `css/` and `js/` folders intact).
3. Click **Commit changes**.
4. Go to **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **Deploy from a branch**.
6. Set branch to `main` and folder to `/ (root)`, then click **Save**.
7. Wait 1–2 minutes. Your site will be live at:
   `https://<your-github-username>.github.io/bornstar-website/`

**Option B — Using git from your computer:**
```bash
cd bornstar
git init
git add .
git commit -m "Launch BornStar Technology website"
git branch -M main
git remote add origin https://github.com/<your-username>/bornstar-website.git
git push -u origin main
```
Then enable Pages the same way as steps 4–6 above.

## After deploying
- Update the WhatsApp number/link in every page if it changes (`https://wa.me/27781759560`).
- Swap the `mailto:hello@bornstartech.co.za` address in `js/main.js` and the footer/contact page for your real inbox if different.
- Replace the `map-placeholder` div in `contact.html` with a real Google Maps `<iframe>` embed once you have a pinned location.
- If you later buy a custom domain, add a `CNAME` file with the domain name and point your DNS at GitHub Pages — no code changes needed.

## Notes
- Fonts (Poppins/Inter) load from Google Fonts via CDN — works out of the box on GitHub Pages.
- The contact form has no backend (GitHub Pages is static hosting only). Submitting it opens the visitor's email app pre-filled with their message. For a fully automated inbox, connect the form to a service like Formspree later — it's a one-line change.
